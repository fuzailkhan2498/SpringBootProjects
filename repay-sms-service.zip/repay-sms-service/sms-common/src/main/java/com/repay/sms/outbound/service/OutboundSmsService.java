package com.repay.sms.outbound.service;

import com.repay.sms.domain.Merchant;
import com.repay.sms.exception.OutboundSmsException;
import com.repay.sms.type.Provider;

public interface OutboundSmsService {

	/**
	 * Send SMS message
	 * 
	 * @param merchant
	 * @param destinationNumber
	 * @param message
	 * @throws OutboundSmsException
	 */
	public void sendMessage(Merchant merchant, String destinationNumber, String message) throws OutboundSmsException;

	/**
	 * 
	 * @return provider
	 */
	public Provider getProvider();

}
