package com.repay.sms.repository;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.repay.sms.domain.TwillioCredential;

@Repository
public class TwillioCredentialRepositoryImpl implements TwillioCredentialRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String CREATE_TWILIO_CRED_QUERY = "INSERT INTO twillio_credential(id, accountsid, authid) values (?, ?, ?)";

	@Override
	public TwillioCredential save(TwillioCredential twilioCred) {
		jdbcTemplate.update(CREATE_TWILIO_CRED_QUERY,
				twilioCred.getId() == null ? UUID.randomUUID().toString() : twilioCred.getId(),
				twilioCred.getAccountSid(), twilioCred.getAuthId());
		return twilioCred;
	}

}
