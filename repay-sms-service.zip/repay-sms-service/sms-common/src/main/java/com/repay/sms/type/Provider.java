package com.repay.sms.type;

public enum Provider {
	TWILIO, PINPOINT
}
