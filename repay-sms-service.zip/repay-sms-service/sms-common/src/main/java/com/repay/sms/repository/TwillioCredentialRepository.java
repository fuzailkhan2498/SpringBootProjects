package com.repay.sms.repository;

import org.springframework.stereotype.Repository;

import com.repay.sms.domain.TwillioCredential;

@Repository
public interface TwillioCredentialRepository {

	TwillioCredential save(TwillioCredential merchant);

}
