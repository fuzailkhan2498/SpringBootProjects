package com.repay.sms.outbound.service.pinpoint;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.repay.sms.domain.Merchant;
import com.repay.sms.domain.PinpointCredential;
import com.repay.sms.exception.OutboundSmsException;
import com.repay.sms.outbound.service.OutboundSmsService;
import com.repay.sms.type.Provider;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentials;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.pinpoint.PinpointClient;
import software.amazon.awssdk.services.pinpoint.model.AddressConfiguration;
import software.amazon.awssdk.services.pinpoint.model.ChannelType;
import software.amazon.awssdk.services.pinpoint.model.DirectMessageConfiguration;
import software.amazon.awssdk.services.pinpoint.model.MessageRequest;
import software.amazon.awssdk.services.pinpoint.model.MessageResponse;
import software.amazon.awssdk.services.pinpoint.model.SMSMessage;
import software.amazon.awssdk.services.pinpoint.model.SMSMessage.Builder;
import software.amazon.awssdk.services.pinpoint.model.SendMessagesRequest;
import software.amazon.awssdk.services.pinpoint.model.SendMessagesResponse;

@Slf4j
@Service
@RequiredArgsConstructor
public class PinpointOutboundSmsServiceImpl implements OutboundSmsService {
	
	private PinpointClient init(PinpointCredential cred) {
		final AwsCredentials credentials = AwsBasicCredentials.create(cred.getAcceessId(), cred.getSecret());
		final AwsCredentialsProvider credentialsProvider = StaticCredentialsProvider.create(credentials);

		return PinpointClient.builder().region(Region.of(cred.getRegion())).credentialsProvider(credentialsProvider).build();
	}

	public static String messageType = "PROMOTIONAL";

	public void sendMessage(Merchant merchant, String destinationNumber, String message) throws OutboundSmsException {
		PinpointCredential cred = merchant.getPinpointCredential();
		validatePinpointCred(cred);
		PinpointClient pinpointClient = init(cred); 
		sendSMSMessage(pinpointClient, message, cred.getAppId(), merchant.getOriginationNumber(), destinationNumber, merchant);
	}

	public static void sendSMSMessage(PinpointClient pinpoint, String message, String appId, String originationNumber,
			String destinationNumber, Merchant merchant) {
		log.info("sending message to {} via pinpoint", destinationNumber);

		try {
			Map<String, AddressConfiguration> addressMap = new HashMap<String, AddressConfiguration>();
			AddressConfiguration addConfig = AddressConfiguration.builder().channelType(ChannelType.SMS).build();

			addressMap.put(destinationNumber, addConfig);
			
			SMSMessage smsMessage = buildSMSMessage(merchant, message, originationNumber);

			// Create a DirectMessageConfiguration object.
			DirectMessageConfiguration direct = DirectMessageConfiguration.builder().smsMessage(smsMessage).build();

			MessageRequest msgReq = MessageRequest.builder().addresses(addressMap).messageConfiguration(direct).build();

			// create a SendMessagesRequest object
			SendMessagesRequest request = SendMessagesRequest.builder().applicationId(appId).messageRequest(msgReq)
					.build();

			SendMessagesResponse response = pinpoint.sendMessages(request);
			MessageResponse msg1 = response.messageResponse();
			Map map1 = msg1.result();

			// Write out the result of sendMessage.
			map1.forEach((k, v) -> log.info((k + ":" + v)));

		} catch (Exception e) {
			log.error("Error while sending Pinpoint SMS message", e);
		}
	}
	
	@SneakyThrows
	private void validatePinpointCred(PinpointCredential cred) {
		if (!StringUtils.hasText(cred.getAcceessId())) {
			throw new OutboundSmsException("Access ID is missing");
		}

		if (!StringUtils.hasText(cred.getSecret())) {
			throw new OutboundSmsException("Secret is missing");
		}

		if (!StringUtils.hasText(cred.getRegion())) {
			throw new OutboundSmsException("Region is missing");
		}

		if (!StringUtils.hasText(cred.getAppId())) {
			throw new OutboundSmsException("App ID is missing");
		}
	}
	
	private static SMSMessage buildSMSMessage(Merchant merchant, String message, String originationNumber) {
		Builder builder = SMSMessage.builder();
		builder.body(message).messageType(messageType);

		if (merchant.getOriginationUsage() != null) {
			switch (merchant.getOriginationUsage()) {
			case SENDER_ID_ORIGINATION_NUM:
				builder.senderId(merchant.getSenderId());
				builder.originationNumber(originationNumber);
				break;
			case ORIGINATION_NUM:
				builder.originationNumber(originationNumber);
				break;
			case SENDER_ID:
				builder.senderId(merchant.getSenderId());
				break;
			default:
				break;
			}
		}

		return builder.build();
	}

	@Override
	public Provider getProvider() {
		return Provider.PINPOINT;
	}

}
