package com.repay.sms.type;

public enum OriginationUsage {
	SENDER_ID, ORIGINATION_NUM, SENDER_ID_ORIGINATION_NUM
}
