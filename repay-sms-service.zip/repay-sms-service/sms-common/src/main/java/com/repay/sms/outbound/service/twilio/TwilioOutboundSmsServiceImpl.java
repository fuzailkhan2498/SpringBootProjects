package com.repay.sms.outbound.service.twilio;

import java.util.regex.Pattern;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.repay.sms.domain.Merchant;
import com.repay.sms.domain.TwillioCredential;
import com.repay.sms.exception.OutboundSmsException;
import com.repay.sms.outbound.service.OutboundSmsService;
import com.repay.sms.type.Provider;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TwilioOutboundSmsServiceImpl implements OutboundSmsService {

	/**
	*
	*/
	private void initTwilio(TwillioCredential cred) {
		Twilio.init(cred.getAccountSid(), cred.getAuthId());
	}

	@Override
	@SneakyThrows
	public void sendMessage(Merchant merchant, String destinationNumber, String smsMessage) {
		log.info("sending message to {} via Twilio", destinationNumber);

		TwillioCredential cred = merchant.getTwilioCredential();
		validateTwillioCred(cred);
		initTwilio(cred);

		try {
			Message message = Message
					.creator(new PhoneNumber(destinationNumber), new PhoneNumber(merchant.getOriginationNumber()),
							smsMessage)
					// .setStatusCallback(
					// URI.create("https://2b3c-122-161-52-36.in.ngrok.io/api/v1/sms/webhook/twilio/status"))
					.create();

			log.info("message: {}", message);
		} catch (Exception ex) {
			throw new OutboundSmsException(ex.getMessage(), ex);
		}
	}

	@SneakyThrows
	private void validateTwillioCred(TwillioCredential cred) {
		if (!StringUtils.hasText(cred.getAccountSid())) {
			throw new OutboundSmsException("Account SID is missing");
		}

		if (!StringUtils.hasText(cred.getAuthId())) {
			throw new OutboundSmsException("AuthID is missing");
		}
	}

	private boolean isPhoneNumberValid(String phoneNumber) {
		final String pattern = "^\\+(?:[0-9]â—�?){6,14}[0-9]$";
		return Pattern.matches(pattern, phoneNumber);
	}

	@Override
	public Provider getProvider() {
		return Provider.TWILIO;
	}

}
