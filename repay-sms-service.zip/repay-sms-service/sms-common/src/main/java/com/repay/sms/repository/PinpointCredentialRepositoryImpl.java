package com.repay.sms.repository;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.repay.sms.domain.PinpointCredential;

@Repository
public class PinpointCredentialRepositoryImpl implements PinpointCredentialRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String CREATE_PINPOINT_CRED_QUERY = "INSERT INTO pinpoint_credential(id, acceessid, appid, region, secret) values (?, ?, ?, ?, ?)";

	@Override
	public PinpointCredential save(PinpointCredential pinpointCred) {
		jdbcTemplate.update(CREATE_PINPOINT_CRED_QUERY,
				pinpointCred.getId() == null ? UUID.randomUUID().toString() : pinpointCred.getId(),
				pinpointCred.getAcceessId(), pinpointCred.getAppId(), pinpointCred.getRegion(),
				pinpointCred.getSecret());
		return pinpointCred;
	}

}
