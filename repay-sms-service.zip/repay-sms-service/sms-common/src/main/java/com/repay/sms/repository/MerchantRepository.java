package com.repay.sms.repository;

import java.util.List;
import java.util.Optional;

import com.repay.sms.domain.Merchant;

public interface MerchantRepository {

	Merchant save(Merchant merchant);

	List<Merchant> findAll();

	void delete(Merchant merchant);

	Optional<Merchant> findByMerchantId(String merchantId);

}
