package com.repay.sms.repository;

import org.springframework.stereotype.Component;

import com.repay.sms.domain.SmsRequest;

@Component
public interface SmsRequestRepository {
	
	SmsRequest save(SmsRequest smsRequest);

}
