package com.repay.sms.repository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.repay.sms.domain.Merchant;
import com.repay.sms.domain.PinpointCredential;
import com.repay.sms.domain.TwillioCredential;
import com.repay.sms.type.OriginationUsage;
import com.repay.sms.type.Provider;

@Repository
public class MerchantRepositoryImpl implements MerchantRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static DateTimeFormatter formatter = new DateTimeFormatterBuilder()
			// here is the same as your code
			.appendPattern("yyyy-mm-dd").appendLiteral(" ")
			// time (hour/minute/seconds)
			.appendPattern("HH:mm:ss").appendLiteral(".")
			// optional nanos, with 9, 6 or 3 digits
			.appendValue(ChronoField.MILLI_OF_SECOND, 6)
			// .appendPattern(".SSSSSS")
			// offset
			// .appendOffset("+HH:mm", "Z")
			// create formatter
			.toFormatter();

	private static final String CREATE_MERCHANT_QUERY = "INSERT INTO merchant(id, datecreated, lastupdated, merchantid, merchantname, originationnumber, originationusage, provider, senderid, pinpointcred, twilliocred) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	private static final String FIND_ALL_MERCHANT_QUERY = "SELECT m.id as mid, t.id as tid, p.id as pid, * FROM merchant as m left join twillio_credential as t on m.twilliocred = t.id left join pinpoint_credential as p on m.pinpointcred = p.id";

	private static final String FIND_BY_MERCHANT_ID = "SELECT m.id as mid, t.id as tid, p.id as pid, * FROM merchant as m left join twillio_credential as t on m.twilliocred = t.id left join pinpoint_credential as p on m.pinpointcred = p.id WHERE  merchantid=?";

	private static final String DELETE_MERCHANT_BY_ID = "DELETE FROM merchant WHERE id=?";

	@Override
	public Merchant save(Merchant merchant) {
		jdbcTemplate.update(CREATE_MERCHANT_QUERY,
				merchant.getId() == null ? UUID.randomUUID().toString() : merchant.getId(), LocalDateTime.now(),
				LocalDateTime.now(), merchant.getMerchantId(), merchant.getMerchantName(),
				merchant.getOriginationNumber(),
				merchant.getOriginationUsage() == null ? null : merchant.getOriginationUsage().name(),
				merchant.getProvider() == null ? null : merchant.getProvider().name(), merchant.getSenderId(),
				merchant.getPinpointCredential() == null ? null : merchant.getPinpointCredential().getId(),
				merchant.getTwilioCredential() == null ? null : merchant.getTwilioCredential().getId());
		return merchant;
	}

	@Override
	public List<Merchant> findAll() {
		return jdbcTemplate.query(FIND_ALL_MERCHANT_QUERY, (rs, rowNum) -> {

			PinpointCredential pinpointCredential = null;
			if (rs.getString("pinpointcred") != null) {
				pinpointCredential = PinpointCredential.builder().id(rs.getString("pid"))
						.acceessId(rs.getString("acceessid")).appId(rs.getString("appid"))
						.secret(rs.getString("secret")).region(rs.getString("region")).build();
			}

			TwillioCredential twillioCredential = null;
			if (rs.getString("twilliocred") != null) {
				twillioCredential = TwillioCredential.builder().id(rs.getString("tid"))
						.accountSid(rs.getString("accountsid")).authId(rs.getString("authid")).build();
			}

			return Merchant.builder().id(rs.getString("mid")).twilioCredential(twillioCredential)
					.pinpointCredential(pinpointCredential).merchantId(rs.getString("merchantid"))
					.merchantName(rs.getString("merchantname")).originationNumber(rs.getString("originationnumber"))
					.originationUsage(rs.getString("originationusage") == null ? null
							: OriginationUsage.valueOf(rs.getString("originationusage")))
					.provider(rs.getString("provider") == null ? null : Provider.valueOf(rs.getString("provider")))
					.senderId(rs.getString("senderid"))
					// .lastUpdated(LocalDateTime.parse(rs.getString("lastupdated"), formatter))
					.build();
		});
	}

	@Override
	public void delete(Merchant merchant) {
		jdbcTemplate.update(DELETE_MERCHANT_BY_ID, merchant.getId());
	}

	@Override
	public Optional<Merchant> findByMerchantId(String merchantId) {
		return jdbcTemplate.query(FIND_BY_MERCHANT_ID, (rs, rowNum) -> {
			PinpointCredential pinpointCredential = null;
			if (rs.getString("pinpointcred") != null) {
				pinpointCredential = PinpointCredential.builder().id(rs.getString("pid"))
						.acceessId(rs.getString("acceessid")).appId(rs.getString("appid"))
						.secret(rs.getString("secret")).region(rs.getString("region")).build();
			}

			TwillioCredential twillioCredential = null;
			if (rs.getString("twilliocred") != null) {
				twillioCredential = TwillioCredential.builder().id(rs.getString("tid"))
						.accountSid(rs.getString("accountsid")).authId(rs.getString("authid")).build();
			}

			return Merchant.builder().id(rs.getString("mid")).twilioCredential(twillioCredential)
					.pinpointCredential(pinpointCredential).merchantId(rs.getString("merchantid"))
					.merchantName(rs.getString("merchantname")).originationNumber(rs.getString("originationnumber"))
					.originationUsage(rs.getString("originationusage") == null ? null
							: OriginationUsage.valueOf(rs.getString("originationusage")))
					.provider(rs.getString("provider") == null ? null : Provider.valueOf(rs.getString("provider")))
					.senderId(rs.getString("senderid"))
					// .lastUpdated(LocalDateTime.parse(rs.getString("lastupdated"), formatter))
					.build();
		}, merchantId).stream().findAny();
	}

}
