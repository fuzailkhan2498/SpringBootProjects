package com.repay.sms.exception;

public class MerchantNotFoundException extends Exception {

	private static final long serialVersionUID = -928081536659469152L;

	/**
     *
     * @param msg
     */
    public MerchantNotFoundException(String msg) {
        super(msg);
    }

    /**
     *
     * @param t
     */
    public MerchantNotFoundException(Throwable t) {
        super(t);
    }

    /**
     *
     * @param msg
     * @param t
     */
    public MerchantNotFoundException(String msg, Throwable t) {
        super(msg, t);
    }
}