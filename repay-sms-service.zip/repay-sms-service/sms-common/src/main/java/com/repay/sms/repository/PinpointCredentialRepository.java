package com.repay.sms.repository;

import org.springframework.stereotype.Repository;

import com.repay.sms.domain.PinpointCredential;

@Repository
public interface PinpointCredentialRepository {

	PinpointCredential save(PinpointCredential merchant);

}
