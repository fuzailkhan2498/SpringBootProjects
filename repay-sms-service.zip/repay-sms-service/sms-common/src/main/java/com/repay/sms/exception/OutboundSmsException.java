package com.repay.sms.exception;

public class OutboundSmsException extends Exception {

    private static final long serialVersionUID = -7126594606670988334L;

	/**
     *
     * @param msg
     */
    public OutboundSmsException(String msg) {
        super(msg);
    }

    /**
     *
     * @param t
     */
    public OutboundSmsException(Throwable t) {
        super(t);
    }

    /**
     *
     * @param msg
     * @param t
     */
    public OutboundSmsException(String msg, Throwable t) {
        super(msg, t);
    }
}
