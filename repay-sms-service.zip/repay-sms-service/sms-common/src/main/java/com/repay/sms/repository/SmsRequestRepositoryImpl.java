package com.repay.sms.repository;

import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.repay.sms.domain.SmsRequest;

@Repository
public class SmsRequestRepositoryImpl implements SmsRequestRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	private static final String CREATE_SMS_REQ_QUERY = "INSERT INTO sms_request(id, datecreated, destinationnumber, lastupdated, merchantid, message, provider) values (?, ?, ?, ?, ?, ?, ?)";

	@Override
	public SmsRequest save(SmsRequest smsRequest) {
		jdbcTemplate.update(CREATE_SMS_REQ_QUERY,
				smsRequest.getId() == null ? UUID.randomUUID().toString() : smsRequest.getId(),
				smsRequest.getDateCreated() == null ? LocalDateTime.now() : smsRequest.getDateCreated(),
				smsRequest.getDestinationNumber(), LocalDateTime.now(), smsRequest.getMerchantId(),
				smsRequest.getMessage(), smsRequest.getProvider() == null ? null : smsRequest.getProvider().name());
		return smsRequest;
	}

}
