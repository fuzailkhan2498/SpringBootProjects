package com.repay.sms.outbound.service.factory;

import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.repay.sms.exception.OutboundSmsException;
import com.repay.sms.outbound.service.OutboundSmsService;
import com.repay.sms.type.Provider;

import lombok.SneakyThrows;

@Service
public class OutboundSmsServiceFactory {

	@Autowired
	private List<OutboundSmsService> outboundSmsServices;

	@SneakyThrows
	public OutboundSmsService getOutboundSmsServiceImpl(Provider provider) {
		return outboundSmsServices.stream()
				.filter(outboundSmsService -> Objects.equals(provider, outboundSmsService.getProvider())).findFirst()
				.orElseThrow(
						() -> new OutboundSmsException(String.format(" Provider Not Found - %s", provider.name())));
	}

}
