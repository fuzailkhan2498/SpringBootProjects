package com.repay.sms.exception;

public class MerchantException extends Exception {

    private static final long serialVersionUID = -7126594606670988334L;

	/**
     *
     * @param msg
     */
    public MerchantException(String msg) {
        super(msg);
    }

    /**
     *
     * @param t
     */
    public MerchantException(Throwable t) {
        super(t);
    }

    /**
     *
     * @param msg
     * @param t
     */
    public MerchantException(String msg, Throwable t) {
        super(msg, t);
    }
}
