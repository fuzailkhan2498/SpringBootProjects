
# Project Title

A brief description of what this project does and who it's for

# repay-sms-service

## sms-req-api:

This will be the entry point for the external services. This will accept the message request and store it in the DB and publish a SNS notification. All the messages from the SNS will be stored in the queue. 

## sms-outbound-sqs-listener:
This Lambda funtion will be listening the messages from the SQS, and call the API to send the messages.

## sms-send
This is the Lambda function that will send the SMS message. It has currently support of Twillio.


# repay-sms-service


## sms-req-api:

This will be the entry point for the external services. This will accept the message request and store it in the DB and publish a SNS notification. All the messages from the SNS will be stored in the queue. 

## sms-outbound-sqs-listener:
This Lambda funtion will be listening the messages from the SQS, and call the API to send the messages.

## sms-send
This is the Lambda function that will send the SMS message. It has currently support of Twillio.


# repay-sms-service


## sms-req-api:

This will be the entry point for the external services. This will accept the message request and store it in the DB and publish a SNS notification. All the messages from the SNS will be stored in the queue. 

## sms-outbound-sqs-listener:
This Lambda funtion will be listening the messages from the SQS, and call the API to send the messages.

## sms-send
This is the Lambda function that will send the SMS message. It has currently support of Twillio.



## Installation

#### Install serverless using npm

```bash
  npm install -g serverless

```

#### Set credentials in the AWS credentials profile file on your local system, located at:

```bash
~/.aws/credentials on Linux, macOS, or Unix

C:\Users\USERNAME\.aws\credentials on Windows

```

#### The above file should contain lines in the following format:

```bash
[default]
aws_access_key_id = your_access_key_id
aws_secret_access_key = your_secret_access_key

```
    

## Build

To build each project run

```bash
  mvn clean install
```

## Deployment

To deploy this project run

```bash
  serverless --org={serverless-org-name-without-parenthesis}
  serverless deploy
 ```

## Local Maven Dependecy

```bash
mvn install:install-file \
   -Dfile=<path-to-file> \
   -DgroupId=<group-id> \
   -DartifactId=<artifact-id> \
   -Dversion=<version> \
   -Dpackaging=<packaging> \
   -DgeneratePom=true
  ``` 

### Sample example command for 
```bash
mvn install:install-file -Dfile=D:\Projects\wittybrains\repay\src\repay-sms-service\sms-common\target\sms-1.0.0.jar -DgroupId=com.repay.sms -DartifactId=repay-sms-common -Dversion=1.0.0 -Dpackaging=jar -DgeneratePom=true
```

We can use use the above locally installed dependecy as :

```bash
<dependency>
			<groupId>com.repay.sms</groupId>
			<artifactId>repay-sms-common</artifactId>
			<version>1.0.0</version>
</dependency>
```