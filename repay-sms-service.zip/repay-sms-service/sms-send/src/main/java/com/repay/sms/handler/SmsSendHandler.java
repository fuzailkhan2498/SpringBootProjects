package com.repay.sms.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.repay.sms.config.SpringConfig;
import com.repay.sms.domain.Merchant;
import com.repay.sms.domain.SmsRequest;
import com.repay.sms.exception.OutboundSmsException;
import com.repay.sms.outbound.service.OutboundSmsService;
import com.repay.sms.outbound.service.factory.OutboundSmsServiceFactory;
import com.repay.sms.repository.MerchantRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SmsSendHandler extends AbstractHandler<SpringConfig> implements RequestHandler<SmsRequest, ResponseEntity<?>> {

	public SmsSendHandler() {
		// default constructor
	}

	public ResponseEntity<?> handleRequest(SmsRequest request, Context context) {
		log.info("Submit a SMS message :: {}", request.toString());

		try {
			MerchantRepository merchantRepository = getApplicationContext().getBean(MerchantRepository.class);
			OutboundSmsServiceFactory outboundSmsServiceFactory = getApplicationContext()
					.getBean(OutboundSmsServiceFactory.class);
			Merchant merchant = merchantRepository.findByMerchantId(request.getMerchantId())
					.orElseThrow(() -> new OutboundSmsException("Merchant not found in the system"));
			OutboundSmsService outboundSmsService = outboundSmsServiceFactory
					.getOutboundSmsServiceImpl(request.getProvider());
			outboundSmsService.sendMessage(merchant, request.getDestinationNumber(), request.getMessage());
			return ResponseEntity.status(HttpStatus.ACCEPTED).build();
		} catch (Exception ex) {
			log.error("error sending SMS message", ex);
			return new ResponseEntity<>("Unable to send SMS message", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
