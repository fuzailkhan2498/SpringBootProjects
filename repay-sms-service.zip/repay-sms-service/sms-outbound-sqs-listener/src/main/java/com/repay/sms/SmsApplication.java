package com.repay.sms;

public class SmsApplication {

	public static void main(String[] args) {
	}

}
