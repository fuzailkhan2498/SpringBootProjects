package com.repay.sms.handler;

import com.amazonaws.services.lambda.AWSLambda;
import com.amazonaws.services.lambda.AWSLambdaClientBuilder;
import com.amazonaws.services.lambda.model.InvocationType;
import com.amazonaws.services.lambda.model.InvokeRequest;
import com.amazonaws.services.lambda.model.InvokeResult;
import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.SQSEvent;
import com.amazonaws.services.lambda.runtime.events.SQSEvent.SQSMessage;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class SQSListener implements RequestHandler<SQSEvent, Void> {

	public Void handleRequest(SQSEvent event, Context context) {
		for (SQSMessage msg : event.getRecords()) {
			log.info("Message from SQS {}", msg.getBody());
			try {
				String item = msg.getBody();
				handleHttpRest(item);
			} catch (Exception e) {
				log.info(e.getMessage());
				throw new RuntimeException("Failed to submit task to the worker", e);
			}
		}
		return null;
	}

	@SneakyThrows
	private void handleHttpRest(String reqBody) {
		log.info("Processing message {}", reqBody);
		
		ObjectMapper mapper = new ObjectMapper();
		JsonNode node = mapper.readTree(reqBody);
		
		String message = node.get("message").asText();
		
		log.info("Message data :: {}", message);
		try {
			log.info("Invoking function");
			InvokeResult result = invokeLambda(message);
			log.info("Funtion invoke result - {}", result);
		} catch (Exception e) {
			log.error("Error while invoking the function", e.getMessage());
			e.printStackTrace();
		}
		
	}
	
	private InvokeResult invokeLambda(String requestBody) {
		AWSLambda lambdaClient = AWSLambdaClientBuilder.defaultClient();
		InvokeRequest request = new InvokeRequest();
		request.withFunctionName(System.getenv("SMS_SEND_FUNC")).withInvocationType(InvocationType.RequestResponse)
				.withPayload(requestBody);
		return lambdaClient.invoke(request);
	}

}
