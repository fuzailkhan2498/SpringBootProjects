export const mockData = [
    {
        "id": "e4267b11-c789-4bd0-a09b-bcbd391d01e1",
        "merchantName": "Merchant One",
        "merchantId": "merchant-one-id",
        "originationNumber": "+18507883964",
        "senderId": "test-sender-id",
        "provider": "PINPOINT",
        "pinpointCredential": {
            "id": "eeac427e-acce-4300-bb57-1b020ddf3e9b",
            "acceessId": "AKIAV7HURRIQXUJUJG7S",
            "secret": "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",
            "region": "us-east-1",
            "appId": "da3324ab112340fe89b0f24c516722ef"
        },
        "dateCreated": "2022-11-17T22:45:27.842",
        "lastUpdated": "2022-11-17T22:45:27.842"
    },
    {
        "merchantName": "Merchant 3",
        "merchantId": "merchant-three-id",
        "provider": "TWILIO",
        "originationNumber": "+18507883964",
        "twilioCredential": {
            "authId": "1c29785875e611583114c22cda9c0743",
            "accountSid": "AC68997d06f5cb3c05b1b17586a9dc2bec"
        }
    },
    {
        "merchantName": "Merchant One",
        "merchantId": "merchant-one-id",
        "provider": "PINPOINT",
        "originationNumber": "+18507883964",
        "senderId": "test-sender-id",
        "originationUsage": "SENDER_ID_ORIGINATION_NUM",
        "pinpointCredential": {
            "acceessId": "this-is-access-id",
            "secret": "this-is-secret",
            "appId": "this-is-app-id",
            "region": "us-east-1"
        },
        "twilioCredential": {
            "authId": "this-is-auth-id",
            "accountSid": "this-is-account-sid"
        }
    },
    
    {
        "id": "76e4d012-329f-4ae6-a70e-72e86134400b",
        "merchantName": "Merchant Two",
        "merchantId": "merchant-two-id",
        "originationNumber": "+18507883964",
        "provider": "TWILIO",
        "twilioCredential": {
            "id": "69fa7919-b93a-4ef1-b9f3-768ec219b771",
            "authId": "1c29785875e611583114c22cda9c0743",
            "accountSid": "AC68997d06f5cb3c05b1b17586a9dc2bec"
        },
        "dateCreated": "2022-11-17T22:48:21.457",
        "lastUpdated": "2022-11-17T22:48:21.457"
    }
];


export const awsRegion = [
    'ap-south-1', 
    'eu-west-3',
    'eu-north-1',
    'eu-west-2',
    'eu-west-1',
    'ap-northeast-3',
    'ap-northeast-2',
    'ap-northeast-1',
    'sa-east-1',
    'ca-central-1',
    'ap-southeast-1',
    'ap-southeast-2',
    'eu-central-1',
    'us-east-1',
    'us-east-2',
    'us-west-1',
    'us-west-2',
    'cn-north-1',
    'cn-northwest-1']; 

export const originationUsageOpts=['SENDER_ID','ORIGINATION_NUM','SENDER_ID_ORIGINATION_NUM'];