import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { Post } from '../post';
import { mockData } from 'src/app/mock-data';
      
@Component({
  selector: 'app-index',
  templateUrl: './index.component.html',
  styleUrls: ['./index.component.css']
})
export class IndexComponent implements OnInit {
      
  posts: any[] = [];
  // posts:any []= mockData;
  popup:any;
  providerEle:any;
    
  /*------------------------------------------
  --------------------------------------------
  Created constructor
  --------------------------------------------
  --------------------------------------------*/
  constructor(public postService: PostService) {
    document.addEventListener("click", (args) => { 
      if (args.target != this.popup &&  args.target != this.providerEle) 
      { 
        // console.log('clicked')
        if(this.popup){
        this.popup.classList.remove("show");}
      }
       })
   }
    
  /**
   * Write code on Method
   *
   * @return response()
   */
  ngOnInit(): void {
    this.postService.getAll().subscribe((data: Post[])=>{
      this.posts = data;
      console.log(this.posts);
    })  
  }
    
  deletePost(id:any){
    this.posts = this.posts.filter(item => item.merchantId !== id);
    this.postService.delete(id).subscribe(res => {
         this.posts = this.posts.filter(item => item.merchantId !== id);
         console.log('Post deleted successfully!');
    })
  }
    
  myFunction(i: number) {
    if(this.popup){
      if(this.popup != document.getElementById("myPopup-"+ i)){
      this.popup.classList.remove("show");}
    }
    this.providerEle = document.getElementById("provider-"+i);
    this.popup = document.getElementById("myPopup-"+ i);
    if(this.popup){
      this.popup.classList.toggle("show");
    }
  }
  
}