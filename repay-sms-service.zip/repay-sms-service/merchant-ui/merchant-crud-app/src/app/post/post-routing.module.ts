import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndexComponent } from './index/index.component';
import { ViewComponent } from './view/view.component';
import { CreateComponent } from './create/create.component';
import { EditComponent } from './edit/edit.component';
  
const routes: Routes = [
  { path: 'merchant/index', component: IndexComponent },
  { path: 'merchant/:merchantId/view', component: ViewComponent },
  { path: 'merchant/create', component: CreateComponent },
  { path: 'merchant/:postId/edit', component: EditComponent } ,
  { path: '', redirectTo: 'merchant/index', pathMatch: 'full'},
];
  
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PostRoutingModule { }
