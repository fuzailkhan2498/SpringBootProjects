import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { awsRegion, originationUsageOpts } from 'src/app/mock-data';
     
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
    
  form!: FormGroup;
  providerValue='';
  aws_region = awsRegion;
  origination_usage = originationUsageOpts;
  constructor(
    public postService: PostService,
    private router: Router
  ) { }
    
  ngOnInit(): void {
    this.form = new FormGroup({
      merchantName: new FormControl('', [Validators.required]),
      merchantId: new FormControl('', Validators.required),
      provider: new FormControl(''),
      originationNumber: new FormControl(''),
      senderId: new FormControl(''),
      originationUsage:new FormControl(''),
      twilioCredential:new FormGroup({authId:new FormControl(''),accountSid:new FormControl('')}),
      pinpointCredential:new FormGroup({acceessId:new FormControl(''),secret:new FormControl(''),appId:new FormControl(''),region:new FormControl('')}),
      
    });

  }
    
  get f(){
    return this.form.controls;
  }
    
  submit(){
    
    let temp = this.form.value;
    if(this.providerValue=='TWILIO'){
      delete temp['pinpointCredential'];
    }else{
      delete temp['twilioCredential'];
    }
    // console.log(temp);
    // console.log(this.form.value);
    this.postService.create(temp).subscribe((res:any) => {
         console.log('Post created successfully!');
         this.router.navigateByUrl('merchant/index');
    })
  }

  providerSelection(str: string){
    this.providerValue = str;
  }
  
}