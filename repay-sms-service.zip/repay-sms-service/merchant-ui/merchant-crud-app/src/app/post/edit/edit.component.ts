import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Post } from '../post';
import { FormGroup, FormControl, Validators} from '@angular/forms';
import { awsRegion, mockData, originationUsageOpts } from 'src/app/mock-data';
     
@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
      
  id!: number;
  // post: any = mockData[2];
  post:any={};
  aws_region = awsRegion;
  origination_usage = originationUsageOpts;
  form!: FormGroup;
  providerValue='';
    
  /*------------------------------------------
  --------------------------------------------
  Created constructor
  --------------------------------------------
  --------------------------------------------*/
  constructor(
    public postService: PostService,
    private route: ActivatedRoute,
    private router: Router
  ) { }
    
  /**
   * Write code on Method
   *
   * @return response()
   */
  ngOnInit(): void {
    this.id = this.route.snapshot.params['postId'];
    this.postService.find(this.id).subscribe((data: Post)=>{
      this.post = data;
      this.providerValue = this.post.provider;
    }); 
    
    // this.providerValue = this.post.provider;  //for mockData
    this.form = new FormGroup({
      merchantName: new FormControl('', [Validators.required]),
      merchantId: new FormControl('', Validators.required),
      provider: new FormControl(''),
      originationNumber: new FormControl(''),
      senderId: new FormControl(''),
      originationUsage:new FormControl(''),
      twilioCredential:new FormGroup({authId:new FormControl(''),accountSid:new FormControl('')}),
      pinpointCredential:new FormGroup({acceessId:new FormControl(''),secret:new FormControl(''),appId:new FormControl(''),region:new FormControl('')}),
      
    });
  }

  get f(){
    return this.form.controls;
  }

  submit(){
    
    let temp = this.form.value;
    if(this.providerValue=='TWILIO'){
      delete temp['pinpointCredential'];
    }else{
      delete temp['twilioCredential'];
    }
    // console.log(temp);
    // console.log(this.form.value);
    this.postService.update(temp.merchantId, temp).subscribe((res:any) => {
         console.log('Post updated successfully!');
         this.router.navigateByUrl('merchant/index');
    })
  }
  providerSelection(str: string){
    console.log('this.post.twilioCredential.authId::>',!this.post.twilioCredential);
    if(!this.post.twilioCredential){
      this.post.twilioCredential = {};
    }
    else if(!this.post.pinpointCredential){
      this.post.pinpointCredential = {};
    }
    
    this.providerValue = str;
  }
}