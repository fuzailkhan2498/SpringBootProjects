export const environment = {
  production: true,
  hostUrl : 'http://prod.site',
  username : 'userProd1',
  token:'sdjaj',
  envName:'prod'
};
