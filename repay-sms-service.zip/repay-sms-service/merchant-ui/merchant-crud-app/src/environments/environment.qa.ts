export const environment = {
    production: false,
    hostUrl : 'http://qa.site',
    username : 'userQa1',
    token:'sdjaj',
    envName:'qa'
  };