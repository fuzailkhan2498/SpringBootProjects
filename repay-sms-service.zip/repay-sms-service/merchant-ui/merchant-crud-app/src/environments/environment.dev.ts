export const environment = {
    production: false,
    hostUrl : 'http://dev.site',
    username : 'userDev1',
    token:'sdjaj',
    envName:'dev'
  };