package com.repay.sms.outbound.controller;

import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.repay.sms.domain.SmsRequest;
import com.repay.sms.merchant.service.MerchantService;
import com.repay.sms.messaging.sns.SNSService;
import com.repay.sms.outbound.model.SmsRequestData;
import com.repay.sms.repository.SmsRequestRepository;
import com.repay.sms.type.Provider;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/sms")
public class OutboundSmsController {

	private final SNSService snsService;
	private final SmsRequestRepository smsRequestRepository;
	private final MerchantService merchantService;

	/**
	 * 
	 * @param request
	 * @return
	 */
	@PostMapping(value = "/send")
	public ResponseEntity<?> sendSMSMessage(@RequestBody SmsRequestData request) {
		log.info("Submit a SMS message");
		try {
			Provider provider = merchantService.getProvider(request.getMerchantId());
			SmsRequest smsReq = smsRequestRepository.save(SmsRequest.builder()
					.id(UUID.randomUUID().toString())
					.destinationNumber(request.getDestinationNumber())
					.merchantId(request.getMerchantId())
					.provider(provider)
					.message(request.getMessage()).build());
			snsService.publish(smsReq, request.getMerchantId());
			return ResponseEntity.status(HttpStatus.ACCEPTED).build();
		} catch (Exception ex) {
			log.error("error queuing SMS message", ex);
			return new ResponseEntity<>("Unable to queue SMS message", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
