package com.repay.sms.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class DatabaseConfig {

	private final Environment env;

	@Autowired
	public DatabaseConfig(Environment env) {
		this.env = env;
	}

	/**
	 * Returns the datasource. Currently it is a DriverManagerDataSource object
	 * 
	 * @return DataSource DriverManagerDataSource object
	 */

	@Bean
	public DataSource dataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.postgresql.Driver");
		String dbUrl = env.getProperty("DB_URL");
		if (dbUrl == null) {
			String dbHost = env.getRequiredProperty("DB_HOST");
			String dbPort = env.getRequiredProperty("DB_PORT");
			String dbName = env.getRequiredProperty("DB_NAME");
			dbUrl = "jdbc:postgresql://" + dbHost + ":" + dbPort + "/" + dbName;
		}

		dataSource.setUrl(dbUrl);
		dataSource.setUsername(env.getRequiredProperty("DB_USR"));
		dataSource.setPassword(env.getRequiredProperty("DB_PSWD"));

		return dataSource;
	}
	
	@Bean(name = "applicationJdbcTemplate")
    public JdbcTemplate applicationDataConnection(){
        return new JdbcTemplate(dataSource());
    }

}
