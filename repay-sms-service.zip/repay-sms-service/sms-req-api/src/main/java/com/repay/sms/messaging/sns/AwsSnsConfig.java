package com.repay.sms.messaging.sns;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ConfigurationProperties(prefix = "aws-sns")
public class AwsSnsConfig {
	
	private String smsOutboundReqTopic;
	
	private String region = "us-east-1";
	
	private String accessId;
	
	private String secret;
}
