package com.repay.sms.messaging.sns;

public class MessageException extends RuntimeException {
	private static final long serialVersionUID = -9061213049278013801L;

	public MessageException(String message) {
		super(message);
	}

	public MessageException(Throwable cause) {
		super(cause);
	}

	public MessageException(String message, Throwable cause) {
		super(message, cause);
	}
}
