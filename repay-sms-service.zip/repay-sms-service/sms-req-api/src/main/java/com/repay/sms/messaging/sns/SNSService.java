package com.repay.sms.messaging.sns;

public interface SNSService {

	/**
	 * Publish event object
	 * 
	 * @param event could be a raw map or data structure that can be deserialized as
	 *              a Map
	 */
	void publish(Object event, String messageGroupId) throws MessageException;

}
