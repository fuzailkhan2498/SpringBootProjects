package com.repay.sms.messaging.sns;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Service;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.AmazonSNSClient;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@EnableConfigurationProperties(AwsSnsConfig.class)
public class SNSServiceImpl implements SNSService {

	private final AmazonSNS snsClient;
	private final ObjectMapper objectMapper;
	private final AwsSnsConfig awsSnsConfig;

	@Autowired
	public SNSServiceImpl(AwsSnsConfig config, ObjectMapper objectMapper) {
		this.objectMapper = objectMapper;
		this.awsSnsConfig = config;

		snsClient = AmazonSNSClient.builder().withRegion(Regions.fromName(config.getRegion())).build();
	}

	@Override
	public void publish(Object message, String messageGroupId) throws MessageException {
		String messageBody = serializeMessage(message);
		try {
			publishMessage(messageBody, messageGroupId);
		} catch (Exception e) {
			log.error("Failed to publish message", e);
			throw new MessageException(e);
		}
	}

	private void publishMessage(String message, String messageGroupId) {
		String topicArn = awsSnsConfig.getSmsOutboundReqTopic();

		log.info("Publish message to topic {}: {} ", topicArn, message);

		PublishRequest publishRequest = new PublishRequest(topicArn, message);
		publishRequest.setMessageGroupId(messageGroupId);
		PublishResult publishResult = snsClient.publish(publishRequest);
		if (publishResult != null) {
			log.info("SnsMessage ID {}", publishResult.getMessageId());
		}
	}

	private String serializeMessage(Object event) {
		try {
			return objectMapper.writeValueAsString(event);
		} catch (Exception e) {
			log.error("Failed to serialize object ", e);
			throw new MessageException(e);
		}
	}

}
