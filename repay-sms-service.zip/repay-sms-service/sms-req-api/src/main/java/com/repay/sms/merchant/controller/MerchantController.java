package com.repay.sms.merchant.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.repay.sms.domain.Merchant;
import com.repay.sms.exception.MerchantNotFoundException;
import com.repay.sms.merchant.service.MerchantService;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/merchant")
public class MerchantController {

	private final MerchantService merchantService;

	@PostMapping
	public ResponseEntity<?> saveMerchant(@RequestBody Merchant merchant) {
		log.debug("Saving merchant");
		try {
			merchant = merchantService.validateAndSaveMerchant(merchant);
			return ResponseEntity.status(HttpStatus.OK).body(merchant);
		} catch (Exception ex) {
			log.error("An error ocurred saving merchant data", ex);
			return new ResponseEntity<>("Unable to save Merchant data", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping
	public ResponseEntity<?> getMarchantList() {
		log.debug("Fetching merchant");
		try {
			List<Merchant> merchantList = merchantService.findAll();
			return ResponseEntity.status(HttpStatus.OK).body(merchantList);
		} catch (Exception ex) {
			log.error("An error ocurred fetching Merchant list", ex);
			return new ResponseEntity<>("Unable to fetch Merchant list", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@SneakyThrows
	@GetMapping("/{merchantId}")
	public ResponseEntity<?> getMarchantById(@PathVariable("merchantId") String merchantId) {
		log.debug("Fetching merchant by ID");
		Merchant merchant = merchantService.findByMerchantId(merchantId)
				.orElseThrow(() -> new MerchantNotFoundException("Merchant Not Found"));
		return ResponseEntity.status(HttpStatus.OK).body(merchant);
	}
	

	@SneakyThrows
	@PutMapping("/{merchantId}")
	public ResponseEntity<?> updateMarchantById(@PathVariable("merchantId") String merchantId,
			@RequestBody Merchant merchantData) {
		log.debug("Updating merchant by merchant ID");
		Merchant merchant = merchantService.findByMerchantId(merchantId).map(m -> {
			m.setMerchantId(merchantData.getMerchantId());
			m.setMerchantName(merchantData.getMerchantName());
			m.setOriginationNumber(merchantData.getOriginationNumber());
			m.setOriginationUsage(merchantData.getOriginationUsage());
			m.setPinpointCredential(merchantData.getPinpointCredential());
			m.setProvider(merchantData.getProvider());
			m.setSenderId(merchantData.getSenderId());
			m.setTwilioCredential(merchantData.getTwilioCredential());
			return merchantService.saveMerchant(m);
		}).orElseThrow(() -> new MerchantNotFoundException("Merchant Not Found"));
		return ResponseEntity.status(HttpStatus.OK).body(merchant);
	}

	@SneakyThrows
	@DeleteMapping("/{merchantId}")
	public ResponseEntity<?> deleteMarchantById(@PathVariable("merchantId") String merchantId) {
		log.debug("Deleting merchant by merchant ID");
		Merchant merchant = merchantService.findByMerchantId(merchantId)
				.orElseThrow(() -> new MerchantNotFoundException("Merchant Not Found"));
		merchantService.deleteMerchant(merchant);
		return ResponseEntity.status(HttpStatus.OK).body("Merchant deleted");
	}


}
