package com.repay.sms.merchant.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.repay.sms.domain.Merchant;
import com.repay.sms.domain.PinpointCredential;
import com.repay.sms.exception.MerchantException;
import com.repay.sms.exception.MerchantNotFoundException;
import com.repay.sms.repository.MerchantRepository;
import com.repay.sms.repository.PinpointCredentialRepository;
import com.repay.sms.repository.TwillioCredentialRepository;
import com.repay.sms.type.Provider;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;

@Service
@RequiredArgsConstructor
public class MerchantService {

	private final MerchantRepository merchantRepository;
	private final TwillioCredentialRepository twillioCredentialRepository;
	private final PinpointCredentialRepository pinpointCredentialRepository;

	public Merchant validateAndSaveMerchant(Merchant merchant) {
		validateMerchantData(merchant);
		return saveMerchant(merchant);
	}

	public Merchant saveMerchant(Merchant merchant) {
		if (merchant.getId() == null)
			merchant.setId(UUID.randomUUID().toString());
		if (merchant.getTwilioCredential() != null) {
			if (merchant.getTwilioCredential().getId() == null)
				merchant.getTwilioCredential().setId(UUID.randomUUID().toString());
			merchant.setTwilioCredential(twillioCredentialRepository.save(merchant.getTwilioCredential()));
		}
		if (merchant.getPinpointCredential() != null) {
			if (merchant.getPinpointCredential().getId() == null)
				merchant.getPinpointCredential().setId(UUID.randomUUID().toString());
			merchant.setPinpointCredential(pinpointCredentialRepository.save(merchant.getPinpointCredential()));
		}
		return merchantRepository.save(merchant);
	}

	public void deleteMerchant(Merchant merchant) {
		merchantRepository.delete(merchant);
	}

	public List<Merchant> findAll() {
		return merchantRepository.findAll();
	}

	public Optional<Merchant> findByMerchantId(String merchantId) {
		return merchantRepository.findByMerchantId(merchantId);
	}

	@SneakyThrows
	public Provider getProvider(String merchantId) {
		Merchant merchant = findByMerchantId(merchantId)
				.orElseThrow(() -> new MerchantNotFoundException("Merchant Not Found"));
		return merchant.getProvider();
	}

	@SneakyThrows
	private void validateMerchantData(Merchant merchant) {
		if (!StringUtils.hasText(merchant.getMerchantId()))
			throw new MerchantException("Merchant ID can not be empty");

		if (findByMerchantId(merchant.getMerchantId()).isPresent())
			throw new MerchantException("Merchant ID already present in the System");

		if (!StringUtils.hasText(merchant.getMerchantName()))
			throw new MerchantException("Merchant name can not be empty");

		if (merchant.getProvider() == null)
			throw new MerchantException("Provider can not be empty");

		if ((Provider.TWILIO.equals(merchant.getProvider()) && merchant.getTwilioCredential() == null)
				|| Provider.PINPOINT.equals(merchant.getProvider()) && merchant.getPinpointCredential() == null) {
			throw new MerchantException("Provider credential can not be empty");
		}
	}

}
